#version 440 core

struct Material
{
    vec3 ambientColor;
    float ambientStrength;
    vec3 diffuseColor;
    vec3 specularColor;
    float shininess;
};

struct DirectionalLight
{
    vec3 direction;
    vec3 ambientColor;
    vec3 diffuseColor;
    vec3 specularColor;
};

struct PointLight
{
    vec3 position;
    vec3 ambientColor;
    vec3 diffuseColor;
    vec3 specularColor;
    float constant;
    float linear;
    float quadratic;
};

struct SpotLight
{
    vec3 position;
    vec3 direction;
    vec3 ambientColor;
    vec3 diffuseColor;
    vec3 specularColor;
    float cutOff;
    float outerCutOff;
    float constant;
    float linear;
    float quadratic;
};

in vec3 fragmentPosition;
in vec3 fragmentVertexNormal;
in vec2 fragmentTextureCoordinate;

out vec4 outFragmentColor;

uniform bool bUseTexture = false;
uniform bool bUseLighting = false;
uniform bool bUseDirectionalLight = true;
uniform bool bUsePointLight = true;
uniform bool bUseSpotLight = true;

uniform vec4 objectColor = vec4(1.0);
uniform sampler2D objectTexture;
uniform vec3 viewPosition;
uniform vec2 UVscale = vec2(1.0, 1.0);
uniform vec3 globalAmbientColor = vec3(0.2);

uniform Material material;
uniform DirectionalLight directionalLight;
uniform PointLight pointLight;
uniform SpotLight spotLight;

vec3 CalculateDirectionalLight(
    DirectionalLight light,
    vec3 normal,
    vec3 viewDirection);

vec3 CalculatePointLight(
    PointLight light,
    vec3 normal,
    vec3 viewDirection);

vec3 CalculateSpotLight(
    SpotLight light,
    vec3 normal,
    vec3 viewDirection);

void main()
{
    vec4 baseColor;

    if (bUseTexture)
    {
        baseColor = texture(
            objectTexture,
            fragmentTextureCoordinate * UVscale);
    }
    else
    {
        baseColor = objectColor;
    }

    if (!bUseLighting)
    {
        outFragmentColor = baseColor;
        return;
    }

    vec3 normal = normalize(fragmentVertexNormal);
    vec3 viewDirection = normalize(viewPosition - fragmentPosition);

    // Global ambient prevents completely black surfaces while the
    // three light calculations provide diffuse and specular detail.
    vec3 phongResult =
        globalAmbientColor * material.ambientColor;

    if (bUseDirectionalLight)
    {
        phongResult += CalculateDirectionalLight(
            directionalLight,
            normal,
            viewDirection);
    }

    if (bUsePointLight)
    {
        phongResult += CalculatePointLight(
            pointLight,
            normal,
            viewDirection);
    }

    if (bUseSpotLight)
    {
        phongResult += CalculateSpotLight(
            spotLight,
            normal,
            viewDirection);
    }

    outFragmentColor = vec4(
        baseColor.rgb * phongResult,
        baseColor.a);
}

vec3 CalculatePhongTerms(
    vec3 ambientColor,
    vec3 diffuseColor,
    vec3 specularColor,
    vec3 lightDirection,
    vec3 normal,
    vec3 viewDirection)
{
    vec3 ambient =
        ambientColor *
        material.ambientColor *
        material.ambientStrength;

    float diffuseImpact =
        max(dot(normal, lightDirection), 0.0);

    vec3 diffuse =
        diffuseColor *
        material.diffuseColor *
        diffuseImpact;

    vec3 reflectionDirection =
        reflect(-lightDirection, normal);

    float specularPower = pow(
        max(dot(viewDirection, reflectionDirection), 0.0),
        max(material.shininess, 1.0));

    vec3 specular =
        specularColor *
        material.specularColor *
        specularPower;

    return ambient + diffuse + specular;
}

vec3 CalculateDirectionalLight(
    DirectionalLight light,
    vec3 normal,
    vec3 viewDirection)
{
    vec3 lightDirection = normalize(-light.direction);

    return CalculatePhongTerms(
        light.ambientColor,
        light.diffuseColor,
        light.specularColor,
        lightDirection,
        normal,
        viewDirection);
}

vec3 CalculatePointLight(
    PointLight light,
    vec3 normal,
    vec3 viewDirection)
{
    vec3 offset = light.position - fragmentPosition;
    float distanceToLight = length(offset);
    vec3 lightDirection = normalize(offset);

    float attenuation = 1.0 / (
        light.constant +
        light.linear * distanceToLight +
        light.quadratic * distanceToLight * distanceToLight);

    vec3 result = CalculatePhongTerms(
        light.ambientColor,
        light.diffuseColor,
        light.specularColor,
        lightDirection,
        normal,
        viewDirection);

    return result * attenuation;
}

vec3 CalculateSpotLight(
    SpotLight light,
    vec3 normal,
    vec3 viewDirection)
{
    vec3 offset = light.position - fragmentPosition;
    float distanceToLight = length(offset);
    vec3 lightDirection = normalize(offset);

    float theta = dot(
        lightDirection,
        normalize(-light.direction));

    float transitionWidth = max(
        light.cutOff - light.outerCutOff,
        0.0001);

    float coneIntensity = clamp(
        (theta - light.outerCutOff) / transitionWidth,
        0.0,
        1.0);

    float attenuation = 1.0 / (
        light.constant +
        light.linear * distanceToLight +
        light.quadratic * distanceToLight * distanceToLight);

    vec3 result = CalculatePhongTerms(
        light.ambientColor,
        light.diffuseColor,
        light.specularColor,
        lightDirection,
        normal,
        viewDirection);

    return result * attenuation * coneIntensity;
}
