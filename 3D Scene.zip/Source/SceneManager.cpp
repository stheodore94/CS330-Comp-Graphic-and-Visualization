///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;

	// Initialize the texture table before any images are loaded.
	for (int index = 0; index < 16; index++)
	{
		m_textureIDs[index].tag = "";
		m_textureIDs[index].ID = 0;
	}
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	DestroyGLTextures();

	m_pShaderManager = NULL;

	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method loads a texture from an image file and
 *  stores it in the next available texture slot.
 ***********************************************************/
bool SceneManager::CreateGLTexture(
	const char* filename,
	std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// Prevent loading more textures than the table supports.
	if (m_loadedTextures >= 16)
	{
		std::cout
			<< "The maximum number of textures has been loaded."
			<< std::endl;

		return false;
	}

	// Flip the image to match OpenGL texture coordinates.
	stbi_set_flip_vertically_on_load(true);

	// Search from the project directory and from the normal Debug
	// and Release output folders so the EXE can be opened directly.
	const std::string requestedPath(filename);
	const std::string candidates[] =
	{
		requestedPath,
		"../" + requestedPath,
		"../../" + requestedPath
	};

	std::string resolvedPath = requestedPath;
	unsigned char* image = NULL;

	for (const std::string& candidate : candidates)
	{
		image = stbi_load(
			candidate.c_str(),
			&width,
			&height,
			&colorChannels,
			0);

		if (image != NULL)
		{
			resolvedPath = candidate;
			break;
		}
	}

	if (image)
	{
		std::cout
			<< "Successfully loaded image: "
			<< resolvedPath
			<< ", width: "
			<< width
			<< ", height: "
			<< height
			<< ", channels: "
			<< colorChannels
			<< std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// Support RGB images whose row width is not divisible by four.
		glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

		// Repeat textures outside the normal UV range.
		glTexParameteri(
			GL_TEXTURE_2D,
			GL_TEXTURE_WRAP_S,
			GL_REPEAT);

		glTexParameteri(
			GL_TEXTURE_2D,
			GL_TEXTURE_WRAP_T,
			GL_REPEAT);

		// Apply linear texture filtering.
		glTexParameteri(
			GL_TEXTURE_2D,
			GL_TEXTURE_MIN_FILTER,
			GL_LINEAR);

		glTexParameteri(
			GL_TEXTURE_2D,
			GL_TEXTURE_MAG_FILTER,
			GL_LINEAR);

		if (colorChannels == 3)
		{
			glTexImage2D(
				GL_TEXTURE_2D,
				0,
				GL_RGB8,
				width,
				height,
				0,
				GL_RGB,
				GL_UNSIGNED_BYTE,
				image);
		}
		else if (colorChannels == 4)
		{
			glTexImage2D(
				GL_TEXTURE_2D,
				0,
				GL_RGBA8,
				width,
				height,
				0,
				GL_RGBA,
				GL_UNSIGNED_BYTE,
				image);
		}
		else
		{
			std::cout
				<< "Unsupported image channel count: "
				<< colorChannels
				<< std::endl;

			glPixelStorei(GL_UNPACK_ALIGNMENT, 4);

			stbi_image_free(image);
			glDeleteTextures(1, &textureID);

			return false;
		}

		// Generate texture mipmaps.
		glGenerateMipmap(GL_TEXTURE_2D);

		// Restore the default OpenGL alignment.
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);

		// Release the image data from CPU memory.
		stbi_image_free(image);

		// Unbind the texture.
		glBindTexture(GL_TEXTURE_2D, 0);

		// Store the texture ID and tag.
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout
		<< "Could not load image: "
		<< requestedPath
		<< std::endl;

	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method binds each loaded texture to an OpenGL
 *  texture unit.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int index = 0; index < m_loadedTextures; index++)
	{
		glActiveTexture(GL_TEXTURE0 + index);

		glBindTexture(
			GL_TEXTURE_2D,
			m_textureIDs[index].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method releases the loaded OpenGL textures.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int index = 0; index < m_loadedTextures; index++)
	{
		glDeleteTextures(
			1,
			&m_textureIDs[index].ID);
	}

	m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method finds the texture ID associated with a tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
		{
			index++;
		}
	}

	return textureID;
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method finds the texture slot associated with a tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
		{
			index++;
		}
	}

	return textureSlot;
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method finds a previously defined material.
 ***********************************************************/
bool SceneManager::FindMaterial(
	std::string tag,
	OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return false;
	}

	int index = 0;
	bool bFound = false;

	while ((index < m_objectMaterials.size()) &&
		(bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;

			material.ambientColor =
				m_objectMaterials[index].ambientColor;

			material.ambientStrength =
				m_objectMaterials[index].ambientStrength;

			material.diffuseColor =
				m_objectMaterials[index].diffuseColor;

			material.specularColor =
				m_objectMaterials[index].specularColor;

			material.shininess =
				m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return bFound;
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method sets the model transformation matrix.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	scale = glm::scale(scaleXYZ);

	rotationX = glm::rotate(
		glm::radians(XrotationDegrees),
		glm::vec3(1.0f, 0.0f, 0.0f));

	rotationY = glm::rotate(
		glm::radians(YrotationDegrees),
		glm::vec3(0.0f, 1.0f, 0.0f));

	rotationZ = glm::rotate(
		glm::radians(ZrotationDegrees),
		glm::vec3(0.0f, 0.0f, 1.0f));

	translation = glm::translate(positionXYZ);

	// Scale, rotate, and then translate the mesh.
	modelView =
		translation *
		rotationX *
		rotationY *
		rotationZ *
		scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(
			g_ModelName,
			modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method passes a solid color to the shader.
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(
			g_UseTextureName,
			false);

		m_pShaderManager->setVec4Value(
			g_ColorValueName,
			currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method selects a loaded texture for the next mesh.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(
			g_UseTextureName,
			true);

		int textureSlot = FindTextureSlot(textureTag);

		m_pShaderManager->setSampler2DValue(
			g_TextureValueName,
			textureSlot);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method sets the UV scaling used by the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(
	float u,
	float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value(
			"UVscale",
			glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method passes material properties to the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if ((NULL != m_pShaderManager) &&
		(m_objectMaterials.size() > 0))
	{
		OBJECT_MATERIAL material;

		if (FindMaterial(materialTag, material))
		{
			m_pShaderManager->setVec3Value(
				"material.ambientColor",
				material.ambientColor);

			m_pShaderManager->setFloatValue(
				"material.ambientStrength",
				material.ambientStrength);

			m_pShaderManager->setVec3Value(
				"material.diffuseColor",
				material.diffuseColor);

			m_pShaderManager->setVec3Value(
				"material.specularColor",
				material.specularColor);

			m_pShaderManager->setFloatValue(
				"material.shininess",
				material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/**************************************************************/

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method defines how the textured ground and fish
 *  reflect ambient, diffuse, and specular light.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	m_objectMaterials.clear();

	// Soft pink material for the textured ground.
	OBJECT_MATERIAL groundMaterial;

	groundMaterial.ambientColor =
		glm::vec3(0.40f, 0.22f, 0.27f);

	groundMaterial.ambientStrength = 0.10f;

	groundMaterial.diffuseColor =
		glm::vec3(0.52f, 0.34f, 0.39f);

	groundMaterial.specularColor =
		glm::vec3(0.035f, 0.015f, 0.020f);

	groundMaterial.shininess = 12.0f;
	groundMaterial.tag = "groundMaterial";

	m_objectMaterials.push_back(groundMaterial);

	// Mostly neutral material so the fish textures retain
	// their original colors under the colored lighting.
	OBJECT_MATERIAL fishMaterial;

	fishMaterial.ambientColor =
		glm::vec3(0.28f, 0.28f, 0.28f);

	fishMaterial.ambientStrength = 0.14f;

	fishMaterial.diffuseColor =
		glm::vec3(0.56f, 0.56f, 0.56f);

	fishMaterial.specularColor =
		glm::vec3(0.08f, 0.08f, 0.08f);

	fishMaterial.shininess = 16.0f;
	fishMaterial.tag = "fishMaterial";

	m_objectMaterials.push_back(fishMaterial);

	// Neutral matte material used by the painted sign and posts.
	// The final visible color is supplied with SetShaderColor().
	OBJECT_MATERIAL matteMaterial;
	matteMaterial.ambientColor = glm::vec3(0.30f, 0.30f, 0.30f);
	matteMaterial.ambientStrength = 0.16f;
	matteMaterial.diffuseColor = glm::vec3(0.62f, 0.62f, 0.62f);
	matteMaterial.specularColor = glm::vec3(0.03f, 0.03f, 0.03f);
	matteMaterial.shininess = 8.0f;
	matteMaterial.tag = "matteMaterial";
	m_objectMaterials.push_back(matteMaterial);

	// Wood is mostly diffuse and only produces a small highlight.
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.26f, 0.20f, 0.13f);
	woodMaterial.ambientStrength = 0.16f;
	woodMaterial.diffuseColor = glm::vec3(0.58f, 0.46f, 0.31f);
	woodMaterial.specularColor = glm::vec3(0.025f, 0.020f, 0.015f);
	woodMaterial.shininess = 6.0f;
	woodMaterial.tag = "woodMaterial";
	m_objectMaterials.push_back(woodMaterial);

	// The painted metal fence has a slightly stronger highlight.
	OBJECT_MATERIAL metalMaterial;
	metalMaterial.ambientColor = glm::vec3(0.22f, 0.22f, 0.22f);
	metalMaterial.ambientStrength = 0.12f;
	metalMaterial.diffuseColor = glm::vec3(0.48f, 0.48f, 0.48f);
	metalMaterial.specularColor = glm::vec3(0.18f, 0.18f, 0.18f);
	metalMaterial.shininess = 24.0f;
	metalMaterial.tag = "metalMaterial";
	m_objectMaterials.push_back(metalMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method creates three distinct light types: a soft
 *  directional fill, a colored point light, and a spotlight.
 *  Together they satisfy the final-project lighting criteria
 *  without creating harsh two-tone shading.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	// Soft ambient illumination keeps every object visible.
	m_pShaderManager->setVec3Value(
		"globalAmbientColor",
		glm::vec3(0.48f, 0.48f, 0.52f));

	// Neutral directional light aimed toward the front surfaces.
	m_pShaderManager->setVec3Value(
		"directionalLight.direction",
		glm::vec3(0.0f, -0.45f, -1.0f));

	m_pShaderManager->setVec3Value(
		"directionalLight.ambientColor",
		glm::vec3(0.12f, 0.12f, 0.14f));

	m_pShaderManager->setVec3Value(
		"directionalLight.diffuseColor",
		glm::vec3(0.82f, 0.86f, 0.92f));

	m_pShaderManager->setVec3Value(
		"directionalLight.specularColor",
		glm::vec3(0.28f, 0.30f, 0.34f));

	// Warm colored point light from the upper-right.
	m_pShaderManager->setVec3Value(
		"pointLight.position",
		glm::vec3(6.0f, 11.0f, 10.0f));

	m_pShaderManager->setVec3Value(
		"pointLight.ambientColor",
		glm::vec3(0.030f, 0.010f, 0.012f));

	m_pShaderManager->setVec3Value(
		"pointLight.diffuseColor",
		glm::vec3(0.72f, 0.20f, 0.24f));

	m_pShaderManager->setVec3Value(
		"pointLight.specularColor",
		glm::vec3(0.50f, 0.16f, 0.18f));

	m_pShaderManager->setFloatValue(
		"pointLight.constant",
		1.0f);

	m_pShaderManager->setFloatValue(
		"pointLight.linear",
		0.025f);

	m_pShaderManager->setFloatValue(
		"pointLight.quadratic",
		0.0020f);

	// Cool spotlight from the upper-left.
	m_pShaderManager->setVec3Value(
		"spotLight.position",
		glm::vec3(-7.0f, 10.0f, 10.0f));

	m_pShaderManager->setVec3Value(
		"spotLight.direction",
		glm::vec3(0.48f, -0.55f, -0.69f));

	m_pShaderManager->setVec3Value(
		"spotLight.ambientColor",
		glm::vec3(0.010f, 0.015f, 0.025f));

	m_pShaderManager->setVec3Value(
		"spotLight.diffuseColor",
		glm::vec3(0.28f, 0.42f, 0.65f));

	m_pShaderManager->setVec3Value(
		"spotLight.specularColor",
		glm::vec3(0.15f, 0.22f, 0.35f));

	m_pShaderManager->setFloatValue(
		"spotLight.cutOff",
		glm::cos(glm::radians(25.0f)));

	m_pShaderManager->setFloatValue(
		"spotLight.outerCutOff",
		glm::cos(glm::radians(40.0f)));

	m_pShaderManager->setFloatValue(
		"spotLight.constant",
		1.0f);

	m_pShaderManager->setFloatValue(
		"spotLight.linear",
		0.020f);

	m_pShaderManager->setFloatValue(
		"spotLight.quadratic",
		0.0020f);

	m_pShaderManager->setBoolValue(
		"bUseDirectionalLight",
		true);

	m_pShaderManager->setBoolValue(
		"bUsePointLight",
		true);

	m_pShaderManager->setBoolValue(
		"bUseSpotLight",
		true);

	m_pShaderManager->setBoolValue(
		g_UseLightingName,
		true);
}

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method loads the fish and ground textures.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	// Fish body scale texture. Fins and mouths deliberately use
	// shader colors because textures should not be used only as color.
	CreateGLTexture(
		"Project 7 Textures/fish_scales.png",
		"fishScales");

	// Prefer a local copy so the submitted ZIP is self-contained.
	// During development, fall back to the course Utilities folder.
	if (!CreateGLTexture(
		"Project 7 Textures/pavers.jpg",
		"ground"))
	{
		CreateGLTexture(
			"../../Utilities/textures/pavers.jpg",
			"ground");
	}

	BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method loads the textures and meshes and prepares
 *  the materials and lighting.
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Load and bind the textures.
	LoadSceneTextures();

	// Define how the textures reflect light.
	DefineObjectMaterials();

	// Configure the colored key and fill lights.
	SetupSceneLights();

	// Load each mesh once.
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadPrismMesh();
	m_basicMeshes->LoadPyramid3Mesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method transforms and draws the textured ground
 *  and the individual pieces of the fish.
 ***********************************************************/
void SceneManager::RenderScene()
{
	// Create a large horizontal plane beneath the fish.
	SetTransformations(
		glm::vec3(20.0f, 1.0f, 20.0f),
		0.0f,
		0.0f,
		0.0f,
		glm::vec3(0.0f, -4.85f, 0.0f));

	// Tile the ground texture across the plane.
	SetShaderTexture("ground");
	SetTextureUVScale(8.0f, 8.0f);

	// Apply the ground material and enable lighting.
	SetShaderMaterial("groundMaterial");

	m_pShaderManager->setBoolValue(
		g_UseLightingName,
		true);

	m_basicMeshes->DrawPlaneMesh();

	// Helper used to draw the solid-color boxes that construct
	// the sign, wooden display beam, and simplified front fence.
	auto drawBox = [this](
		glm::vec3 size,
		glm::vec3 location,
		glm::vec4 color,
		std::string materialTag)
		{
			SetTransformations(
				size,
				0.0f,
				0.0f,
				0.0f,
				location);

			SetShaderColor(
				color.r,
				color.g,
				color.b,
				color.a);

			SetShaderMaterial(materialTag);
			m_pShaderManager->setBoolValue(g_UseLightingName, true);
			m_basicMeshes->DrawBoxMesh();
		};

	// Large marina sign above the fish display.
	drawBox(
		glm::vec3(15.5f, 4.0f, 0.34f),
		glm::vec3(0.0f, 7.15f, -1.55f),
		glm::vec4(0.08f, 0.09f, 0.19f, 1.0f),
		"matteMaterial");

	// Teal and sand-colored panels reproduce the main color
	// blocks on the weathered Bluepoints Marina sign.
	drawBox(
		glm::vec3(6.7f, 1.45f, 0.08f),
		glm::vec3(-4.35f, 6.45f, -1.34f),
		glm::vec4(0.24f, 0.48f, 0.46f, 1.0f),
		"matteMaterial");

	drawBox(
		glm::vec3(8.15f, 1.45f, 0.08f),
		glm::vec3(3.20f, 6.45f, -1.34f),
		glm::vec4(0.64f, 0.56f, 0.38f, 1.0f),
		"matteMaterial");

	// Pale strips suggest the most prominent lettering while
	// keeping the sign low-polygon.
	drawBox(
		glm::vec3(11.5f, 0.22f, 0.07f),
		glm::vec3(1.50f, 7.95f, -1.29f),
		glm::vec4(0.82f, 0.78f, 0.62f, 1.0f),
		"matteMaterial");

	drawBox(
		glm::vec3(7.8f, 0.34f, 0.07f),
		glm::vec3(-2.50f, 6.85f, -1.28f),
		glm::vec4(0.72f, 0.68f, 0.52f, 1.0f),
		"matteMaterial");

	// Two white cylindrical posts support the sign and beam.
	SetTransformations(
		glm::vec3(0.55f, 10.25f, 0.55f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(-7.05f, -4.80f, -1.20f));
	SetShaderColor(0.78f, 0.78f, 0.73f, 1.0f);
	SetShaderMaterial("matteMaterial");
	m_pShaderManager->setBoolValue(g_UseLightingName, true);
	m_basicMeshes->DrawCylinderMesh();

	SetTransformations(
		glm::vec3(0.55f, 10.25f, 0.55f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(7.05f, -4.80f, -1.20f));
	SetShaderColor(0.78f, 0.78f, 0.73f, 1.0f);
	SetShaderMaterial("matteMaterial");
	m_pShaderManager->setBoolValue(g_UseLightingName, true);
	m_basicMeshes->DrawCylinderMesh();

	// Horizontal wooden beam from which the fish is displayed.
	drawBox(
		glm::vec3(14.0f, 0.72f, 0.72f),
		glm::vec3(0.0f, 3.15f, -0.72f),
		glm::vec4(0.30f, 0.18f, 0.085f, 1.0f),
		"woodMaterial");

	// Simplified front fence. The professor approved using fewer
	// slats, so eleven vertical bars and two rails are sufficient.
	drawBox(
		glm::vec3(15.2f, 0.18f, 0.20f),
		glm::vec3(0.0f, 1.95f, -1.02f),
		glm::vec4(0.035f, 0.040f, 0.045f, 1.0f),
		"metalMaterial");

	drawBox(
		glm::vec3(15.2f, 0.18f, 0.20f),
		glm::vec3(0.0f, -3.65f, -1.02f),
		glm::vec4(0.035f, 0.040f, 0.045f, 1.0f),
		"metalMaterial");

	for (int slat = -5; slat <= 5; slat++)
	{
		drawBox(
			glm::vec3(0.16f, 5.80f, 0.16f),
			glm::vec3(
				static_cast<float>(slat) * 1.35f,
				-0.85f,
				-1.04f),
			glm::vec4(0.025f, 0.030f, 0.035f, 1.0f),
			"metalMaterial");
	}

	// Available meshes used to construct the fish.
	enum class FishMesh
	{
		Cone,
		Taper,
		Cylinder,
		Prism,
		Pyramid
	};

	// This value changes before each fish is drawn so the same
	// modular fish construction can be reused across the beam.
	float activeFishOffsetX = 0.0f;

	// Helper function used to transform, shade, light, and draw
	// each fish component. Only the body uses an image texture.
	// The fins and mouth use shader colors so textures are not
	// misused merely to apply a solid color.
	auto drawPart = [this, &activeFishOffsetX](
		FishMesh mesh,
		glm::vec3 size,
		float xAngle,
		float yAngle,
		float zAngle,
		glm::vec3 location,
		std::string textureTag,
		glm::vec2 uvScale)
		{
			SetTransformations(
				size,
				xAngle,
				yAngle,
				zAngle,
				glm::vec3(
					location.x + activeFishOffsetX,
					location.y,
					location.z));

			if (textureTag == "fishScales")
			{
				SetShaderTexture("fishScales");
				SetTextureUVScale(uvScale.x, uvScale.y);
			}
			else if (textureTag == "fishFins")
			{
				// Dark teal complements the blue-green scale texture.
				SetShaderColor(0.06f, 0.38f, 0.48f, 1.0f);
				SetTextureUVScale(1.0f, 1.0f);
			}
			else
			{
				// Coral-red mouth adds a warm accent to each fish.
				SetShaderColor(0.74f, 0.20f, 0.16f, 1.0f);
				SetTextureUVScale(1.0f, 1.0f);
			}

			SetShaderMaterial("fishMaterial");

			m_pShaderManager->setBoolValue(
				g_UseLightingName,
				true);

			switch (mesh)
			{
			case FishMesh::Cone:
				m_basicMeshes->DrawConeMesh();
				break;

			case FishMesh::Taper:
				m_basicMeshes->DrawTaperedCylinderMesh();
				break;

			case FishMesh::Cylinder:
				m_basicMeshes->DrawCylinderMesh();
				break;

			case FishMesh::Prism:
				m_basicMeshes->DrawPrismMesh();
				break;

			case FishMesh::Pyramid:
				m_basicMeshes->DrawPyramid3Mesh();
				break;
			}
		};

	// Draw four fish to reproduce the repeated hanging-fish
	// arrangement visible in the reference photograph.
	const float fishOffsets[4] =
	{
		-4.80f,
		-1.60f,
		1.60f,
		4.80f
	};

	for (int fishIndex = 0; fishIndex < 4; fishIndex++)
	{
		activeFishOffsetX = fishOffsets[fishIndex];

		// Bottom body section: upside-down oblong cone.
		drawPart(
			FishMesh::Cone,
			glm::vec3(0.48f, 1.05f, 0.25f),
			180.0f,
			0.0f,
			0.0f,
			glm::vec3(0.0f, -2.83f, 0.0f),
			"fishScales",
			glm::vec2(1.0f, 1.25f));

		// Lower body: upside-down oblong tapered cylinder.
		drawPart(
			FishMesh::Taper,
			glm::vec3(1.00f, 1.68f, 0.46f),
			180.0f,
			0.0f,
			0.0f,
			glm::vec3(0.0f, -1.15f, 0.0f),
			"fishScales",
			glm::vec2(1.0f, 1.25f));

		// Middle body: oblong cylinder.
		drawPart(
			FishMesh::Cylinder,
			glm::vec3(1.00f, 2.55f, 0.46f),
			0.0f,
			0.0f,
			0.0f,
			glm::vec3(0.0f, -1.15f, 0.0f),
			"fishScales",
			glm::vec2(1.0f, 1.25f));

		// Upper body: oblong tapered cylinder.
		drawPart(
			FishMesh::Taper,
			glm::vec3(1.00f, 1.85f, 0.46f),
			0.0f,
			0.0f,
			0.0f,
			glm::vec3(0.0f, 1.40f, 0.0f),
			"fishScales",
			glm::vec2(1.0f, 1.25f));

		// Left half of the split tail.
		drawPart(
			FishMesh::Prism,
			glm::vec3(0.78f, 0.08f, 1.80f),
			90.0f,
			-55.0f,
			0.0f,
			glm::vec3(-0.72f, -4.00f, 0.12f),
			"fishFins",
			glm::vec2(1.0f, 1.0f));

		// Right half of the split tail.
		drawPart(
			FishMesh::Prism,
			glm::vec3(0.78f, 0.08f, 1.80f),
			90.0f,
			55.0f,
			0.0f,
			glm::vec3(0.72f, -4.00f, 0.12f),
			"fishFins",
			glm::vec2(1.0f, 1.0f));

		// Right side fin.
		drawPart(
			FishMesh::Prism,
			glm::vec3(1.00f, 0.08f, 0.74f),
			90.0f,
			90.0f,
			0.0f,
			glm::vec3(1.36f, -0.10f, 0.17f),
			"fishFins",
			glm::vec2(1.0f, 1.0f));

		// Small fin beside the mouth.
		drawPart(
			FishMesh::Prism,
			glm::vec3(0.16f, 0.08f, 0.95f),
			-90.0f,
			-15.0f,
			0.0f,
			glm::vec3(-0.62f, 3.59f, 0.20f),
			"fishFins",
			glm::vec2(1.0f, 1.0f));

		// Left piece of the lower mouth.
		drawPart(
			FishMesh::Prism,
			glm::vec3(0.33f, 0.06f, 0.10f),
			0.0f,
			0.0f,
			15.0f,
			glm::vec3(-0.18f, 3.27f, 0.29f),
			"fishMouth",
			glm::vec2(1.0f, 1.0f));

		// Right piece of the lower mouth.
		drawPart(
			FishMesh::Prism,
			glm::vec3(0.33f, 0.06f, 0.10f),
			0.0f,
			0.0f,
			-15.0f,
			glm::vec3(0.18f, 3.27f, 0.29f),
			"fishMouth",
			glm::vec2(1.0f, 1.0f));

		// Three-sided pyramid used for the upper mouth.
		drawPart(
			FishMesh::Pyramid,
			glm::vec3(0.72f, 1.50f, 0.37f),
			0.0f,
			0.0f,
			0.0f,
			glm::vec3(0.0f, 4.00f, 0.04f),
			"fishMouth",
			glm::vec2(1.0f, 1.0f));
	}
}
