///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;

	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;

	// Multiplier changed by the mouse wheel to control
	// the speed of camera movement.
	float gMovementSpeedMultiplier = 1.0f;

	const float MIN_MOVEMENT_SPEED = 0.25f;
	const float MAX_MOVEMENT_SPEED = 4.0f;
	const float VERTICAL_MOVEMENT_SPEED = 2.5f;

	// Projection modes include the required perspective/front views
	// plus top and side orthographic views for extra credit.
	enum class ProjectionMode
	{
		Perspective,
		FrontOrthographic,
		TopOrthographic,
		SideOrthographic
	};

	ProjectionMode gProjectionMode = ProjectionMode::Perspective;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager* pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();

	// Begin far enough away to show the complete marina display,
	// including the ground, fence, fish, support posts, and sign.
	g_pCamera->Position = glm::vec3(0.0f, 2.5f, 22.0f);
	g_pCamera->Front = glm::vec3(0.0f, -0.10f, -1.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 55.0f;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;

	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(
	const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL,
		NULL);

	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}

	glfwMakeContextCurrent(window);

	// Capture the cursor so the mouse can continuously
	// change the orientation of the camera.
	glfwSetInputMode(
		window,
		GLFW_CURSOR,
		GLFW_CURSOR_DISABLED);

	// Receive mouse movement events.
	glfwSetCursorPosCallback(
		window,
		&ViewManager::Mouse_Position_Callback);

	// Receive mouse wheel events.
	glfwSetScrollCallback(
		window,
		&ViewManager::Mouse_Scroll_Callback);

	// enable blending for supporting transparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(
	GLFWwindow* window,
	double xMousePos,
	double yMousePos)
{
	if (NULL == g_pCamera)
	{
		return;
	}

	// Store the first recorded mouse position so that the
	// camera does not suddenly jump when the scene opens.
	if (gFirstMouse)
	{
		gLastX = static_cast<float>(xMousePos);
		gLastY = static_cast<float>(yMousePos);
		gFirstMouse = false;
	}

	// Calculate how far the mouse moved since the previous frame.
	float xOffset =
		static_cast<float>(xMousePos) - gLastX;

	float yOffset =
		gLastY - static_cast<float>(yMousePos);

	// Save the current mouse position.
	gLastX = static_cast<float>(xMousePos);
	gLastY = static_cast<float>(yMousePos);

	// Change the camera orientation.
	g_pCamera->ProcessMouseMovement(
		xOffset,
		yOffset);
}

/***********************************************************
 *  Mouse_Scroll_Callback()
 *
 *  This method changes the speed of camera movement when
 *  the user rotates the mouse wheel.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(
	GLFWwindow* window,
	double xOffset,
	double yOffset)
{
	// Increase speed when scrolling up and decrease speed
	// when scrolling down.
	gMovementSpeedMultiplier +=
		static_cast<float>(yOffset) * 0.25f;

	// Keep the movement speed within a usable range.
	if (gMovementSpeedMultiplier < MIN_MOVEMENT_SPEED)
	{
		gMovementSpeedMultiplier = MIN_MOVEMENT_SPEED;
	}

	if (gMovementSpeedMultiplier > MAX_MOVEMENT_SPEED)
	{
		gMovementSpeedMultiplier = MAX_MOVEMENT_SPEED;
	}
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method is called to process any keyboard events
 *  that may be waiting in the event queue.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// close the window if the escape key has been pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	// Apply the selected speed to horizontal and depth movement.
	float adjustedDeltaTime =
		gDeltaTime * gMovementSpeedMultiplier;

	// W moves the camera forward into the scene.
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			FORWARD,
			adjustedDeltaTime);
	}

	// S moves the camera backward.
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			BACKWARD,
			adjustedDeltaTime);
	}

	// A moves the camera left.
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			LEFT,
			adjustedDeltaTime);
	}

	// D moves the camera right.
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			RIGHT,
			adjustedDeltaTime);
	}

	// Calculate the distance used for vertical movement.
	float verticalDistance =
		VERTICAL_MOVEMENT_SPEED * adjustedDeltaTime;

	// Q moves the camera upward.
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->Position.y += verticalDistance;
	}

	// E moves the camera downward.
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->Position.y -= verticalDistance;
	}

	// P changes the scene to perspective projection.
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
	{
		gProjectionMode = ProjectionMode::Perspective;
	}

	// O selects the required front orthographic view.
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
	{
		gProjectionMode = ProjectionMode::FrontOrthographic;
	}

	// T selects an extra-credit top orthographic view.
	if (glfwGetKey(m_pWindow, GLFW_KEY_T) == GLFW_PRESS)
	{
		gProjectionMode = ProjectionMode::TopOrthographic;
	}

	// R selects an extra-credit right-side orthographic view.
	if (glfwGetKey(m_pWindow, GLFW_KEY_R) == GLFW_PRESS)
	{
		gProjectionMode = ProjectionMode::SideOrthographic;
	}
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;
	glm::vec3 activeViewPosition;

	// per-frame timing
	float currentFrame =
		static_cast<float>(glfwGetTime());

	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// process any keyboard events that may be waiting in the
	// event queue
	ProcessKeyboardEvents();

	// Set the viewport to the complete application window.
	glViewport(
		0,
		0,
		WINDOW_WIDTH,
		WINDOW_HEIGHT);

	if (gProjectionMode == ProjectionMode::FrontOrthographic)
	{
		// The orthographic camera looks directly at the fish.
		// Because the camera does not look downward, the bottom
		// plane is not visible in this mode.
		activeViewPosition =
			glm::vec3(0.0f, 2.0f, 22.0f);

		view = glm::lookAt(
			activeViewPosition,
			glm::vec3(0.0f, 2.0f, 0.0f),
			glm::vec3(0.0f, 1.0f, 0.0f));

		projection = glm::ortho(
			-10.0f,
			10.0f,
			-6.0f,
			10.0f,
			0.1f,
			100.0f);
	}
	else if (gProjectionMode == ProjectionMode::TopOrthographic)
	{
		// Look straight down. A negative-Z up vector keeps the sign
		// and fish arrangement oriented consistently on the screen.
		activeViewPosition = glm::vec3(0.0f, 24.0f, 0.0f);

		view = glm::lookAt(
			activeViewPosition,
			glm::vec3(0.0f, 0.0f, 0.0f),
			glm::vec3(0.0f, 0.0f, -1.0f));

		projection = glm::ortho(
			-12.5f,
			12.5f,
			-10.0f,
			10.0f,
			0.1f,
			100.0f);
	}
	else if (gProjectionMode == ProjectionMode::SideOrthographic)
	{
		// Look directly from the right side toward the scene center.
		activeViewPosition = glm::vec3(24.0f, 2.0f, 0.0f);

		view = glm::lookAt(
			activeViewPosition,
			glm::vec3(0.0f, 2.0f, 0.0f),
			glm::vec3(0.0f, 1.0f, 0.0f));

		projection = glm::ortho(
			-10.0f,
			10.0f,
			-6.0f,
			10.0f,
			0.1f,
			100.0f);
	}
	else
	{
		// Use the movable camera for perspective projection.
		activeViewPosition = g_pCamera->Position;
		view = g_pCamera->GetViewMatrix();

		projection = glm::perspective(
			glm::radians(g_pCamera->Zoom),
			static_cast<GLfloat>(WINDOW_WIDTH) /
			static_cast<GLfloat>(WINDOW_HEIGHT),
			0.1f,
			100.0f);
	}

	// if the shader manager object is valid
	if (NULL != m_pShaderManager)
	{
		// set the view matrix into the shader
		m_pShaderManager->setMat4Value(
			g_ViewName,
			view);

		// set the projection matrix into the shader
		m_pShaderManager->setMat4Value(
			g_ProjectionName,
			projection);

		// set the active camera position into the shader
		m_pShaderManager->setVec3Value(
			"viewPosition",
			activeViewPosition);
	}
}
